print("hello")
x="fggfg"
print(x)
